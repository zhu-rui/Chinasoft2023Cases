package ReportSystem.com.mapper;

import ReportSystem.com.pojo.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

public interface UserMapper {


    @Select("select * from user where user_id = #{username} and password = #{password}")
    @ResultMap("selectUserId")
    User select(@Param("username") String username,@Param("password")  String password);

    @Select("select * from user where user_id = #{username}")
    @ResultMap("selectUserId")
    User selectByUsername(String username);

    @Insert("insert into user values(#{username},#{password})")
    @ResultMap("selectUserId")
    void add(User user);
}
