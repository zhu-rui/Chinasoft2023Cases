package ReportSystem.com.mapper;

import ReportSystem.com.pojo.detail.*;
import org.apache.ibatis.annotations.Param;


import java.util.List;
import java.util.Map;

public interface detStatementMapper {
    List<det_sellC> getDetSellCard(@Param("map") Map<String, Object> map);
    List<det_returnC> getDetReturnCard(@Param("map") Map<String, Object> map);
    List<det_recharge> getDetRecharge(@Param("map") Map<String, Object> map);
    List<det_swipC> getDetSwipCard(@Param("map") Map<String, Object> map);
    List<det_scanCode> getDetScanCode(@Param("map") Map<String, Object> map);
}
