package ReportSystem.com.mapper;

import ReportSystem.com.pojo.check.ExcTotal;
import ReportSystem.com.pojo.check.Except;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ExceptionMapper {

    List<Except> selectECAll(@Param("map") Map<String, Object> map);

    List<ExcTotal> selectETAll(@Param("map") Map<String, Object> map);

}
