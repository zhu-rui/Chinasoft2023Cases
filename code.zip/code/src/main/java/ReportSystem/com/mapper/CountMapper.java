package ReportSystem.com.mapper;

import ReportSystem.com.pojo.count.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CountMapper {
    // 操作员统计表

    List<UCount> selectUCByPageAndCondition(@Param("map") Map<String, Object> map);

    //每日票卡发行表
    List<CCount> selectCCByPageAndCondition(@Param("map") Map<String, Object> map);

    //TVM营收日报表-现金
    List<TCCount> selectTCByPageAndCondition(@Param("map") Map<String, Object> map);
    //TVM营收日报表-电子
    List<TCCount> selectTEByPageAndCondition(@Param("map") Map<String, Object> map);
    //BOM营收日报表-现金
    List<BCCount> selectBCByPageAndCondition(@Param("map") Map<String, Object> map);
    //BOM营收日报表-电子
    List<BCCount> selectBEByPageAndCondition(@Param("map") Map<String, Object> map);
    //营收汇总
    List<TOCount> selectTOCByPageAndCondition(@Param("map") Map<String, Object> map);




}
