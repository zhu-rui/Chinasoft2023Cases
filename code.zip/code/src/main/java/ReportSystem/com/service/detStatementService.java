package ReportSystem.com.service;

import ReportSystem.com.pojo.detail.*;

import java.util.List;
import java.util.Map;

public interface detStatementService {

    /**
     * 查询所有
     * @return
     */
    List<det_sellC> getDetSellCard(Map map);
    List<det_returnC> getDetReturnCard(Map map);
    List<det_recharge> getDetRecharge(Map map);
    List<det_swipC> getDetSwipCard(Map map);
    List<det_scanCode> getDetScanCode(Map map);

}
