package ReportSystem.com.service;


import ReportSystem.com.pojo.check.ExcTotal;
import ReportSystem.com.pojo.check.Except;



import java.util.List;
import java.util.Map;

public interface ExceptionService {

    List<Except> selectECAll(Map map);
    List<ExcTotal> selectETAll(Map map);

}
