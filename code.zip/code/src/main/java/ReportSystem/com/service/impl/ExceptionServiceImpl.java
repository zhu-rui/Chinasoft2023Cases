package ReportSystem.com.service.impl;

import ReportSystem.com.mapper.ExceptionMapper;
import ReportSystem.com.pojo.check.ExcTotal;
import ReportSystem.com.pojo.check.Except;
import ReportSystem.com.service.ExceptionService;
import ReportSystem.com.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class ExceptionServiceImpl implements ExceptionService {

    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    public List<Except> selectECAll(Map map) {
        SqlSession sqlSession = factory.openSession();
        ExceptionMapper mapper = sqlSession.getMapper(ExceptionMapper.class);
        List<Except> excepts = mapper.selectECAll(map);
        sqlSession.close();
        return excepts;
    }

   @Override
    public List<ExcTotal> selectETAll(Map map) {
        SqlSession sqlSession = factory.openSession();
        ExceptionMapper mapper = sqlSession.getMapper(ExceptionMapper.class);
        List<ExcTotal> excTotals = mapper.selectETAll(map);
        sqlSession.close();
        return excTotals;
    }
}
