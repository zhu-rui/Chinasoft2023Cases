package ReportSystem.com.service.impl;

import ReportSystem.com.mapper.CountMapper;
import ReportSystem.com.pojo.PageBean;
import ReportSystem.com.pojo.count.*;
import ReportSystem.com.service.CountService;
import ReportSystem.com.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class CountServiceImpl implements CountService {
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    @Override
    public PageBean<UCount> selectUCByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<UCount> uCounts = mapper.selectUCByPageAndCondition(map);
        PageBean<UCount> pageBean = new PageBean<>();
        pageBean.setRows(uCounts);

        sqlSession.close();
        return pageBean;
    }


    @Override
    public PageBean<CCount> selectCCByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<CCount> cCounts = mapper.selectCCByPageAndCondition(map);
        PageBean<CCount> pageBean = new PageBean<>();
        pageBean.setRows(cCounts);
        sqlSession.close();
        return pageBean;
    }


    @Override
    public PageBean<TCCount> selectTCByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<TCCount> tcCounts = mapper.selectTCByPageAndCondition(map);
        PageBean<TCCount> pageBean = new PageBean<>();
        pageBean.setRows(tcCounts);

        sqlSession.close();
        return pageBean;
    }

    @Override
    public PageBean<TCCount> selectTEByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<TCCount> tcCounts = mapper.selectTEByPageAndCondition(map);
        PageBean<TCCount> pageBean = new PageBean<>();
        pageBean.setRows(tcCounts);

        sqlSession.close();
        return pageBean;
    }

    //BOM

    @Override
    public PageBean<BCCount> selectBCByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<BCCount> bcCounts = mapper.selectBCByPageAndCondition(map);
        PageBean<BCCount> pageBean = new PageBean<>();
        pageBean.setRows(bcCounts);

        sqlSession.close();
        return pageBean;
    }

    @Override
    public PageBean<BCCount> selectBEByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<BCCount> bcCounts = mapper.selectBEByPageAndCondition(map);
        PageBean<BCCount> pageBean = new PageBean<>();
        pageBean.setRows(bcCounts);
        sqlSession.close();
        return pageBean;
    }


    @Override
    public PageBean<TOCount> selectTOCByPageAndCondition(Map map) {
        SqlSession sqlSession = factory.openSession();
        CountMapper mapper = sqlSession.getMapper(CountMapper.class);
        List<TOCount> toCounts = mapper.selectTOCByPageAndCondition(map);
        PageBean<TOCount> pageBean = new PageBean<>();
        pageBean.setRows(toCounts);
        sqlSession.close();
        return pageBean;
    }
}
