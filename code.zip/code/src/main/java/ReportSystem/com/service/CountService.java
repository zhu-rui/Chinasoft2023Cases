package ReportSystem.com.service;

import ReportSystem.com.pojo.PageBean;
import ReportSystem.com.pojo.count.*;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface CountService {
    //操作员统计表
    PageBean<UCount> selectUCByPageAndCondition(Map map);

    //每日票卡发行表
    PageBean<CCount> selectCCByPageAndCondition(Map map);
    //TVM营收现金
    PageBean<TCCount> selectTCByPageAndCondition(Map map);
    //TVM营收电子
    PageBean<TCCount> selectTEByPageAndCondition(Map map);
    //BOM营收现金
    PageBean<BCCount> selectBCByPageAndCondition(Map map);
    //BOM营收电子
    PageBean<BCCount> selectBEByPageAndCondition(Map map);
    //营收汇总日报表
    PageBean<TOCount> selectTOCByPageAndCondition(Map map);



}
