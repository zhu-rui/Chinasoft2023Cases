package ReportSystem.com.service.impl;
import ReportSystem.com.mapper.detStatementMapper;
import ReportSystem.com.pojo.detail.*;
import ReportSystem.com.service.detStatementService;
import ReportSystem.com.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class detStatementServiceImpl implements detStatementService {
    //1. 创建SqlSessionFactory 工厂对象
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    @Override
    public List<det_sellC> getDetSellCard(Map map) {
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        detStatementMapper mapper = sqlSession.getMapper(detStatementMapper.class);
        //4. 调用方法
        List<det_sellC> det_sellc = mapper.getDetSellCard(map);
        //5. 释放资源
        sqlSession.close();
        return det_sellc;
    }

    @Override
    public List<det_returnC> getDetReturnCard(Map map) {
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        detStatementMapper mapper = sqlSession.getMapper(detStatementMapper.class);
        //4. 调用方法
        List<det_returnC> det_returnc = mapper.getDetReturnCard(map);
        //5. 释放资源
        sqlSession.close();
        return det_returnc;
    }

    @Override
    public List<det_recharge> getDetRecharge(Map map) {
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        detStatementMapper mapper = sqlSession.getMapper(detStatementMapper.class);
        //4. 调用方法
        List<det_recharge> det_Recharge = mapper.getDetRecharge(map);
        //5. 释放资源
        sqlSession.close();
        return det_Recharge;
    }

    @Override
    public List<det_swipC> getDetSwipCard(Map map) {
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        detStatementMapper mapper = sqlSession.getMapper(detStatementMapper.class);
        //4. 调用方法
        List<det_swipC> det_swipc = mapper.getDetSwipCard(map);
        //5. 释放资源
        sqlSession.close();
        return det_swipc;
    }

    @Override
    public List<det_scanCode> getDetScanCode(Map map) {
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        detStatementMapper mapper = sqlSession.getMapper(detStatementMapper.class);
        //4. 调用方法
        List<det_scanCode> det_scan_Code = mapper.getDetScanCode(map);
        //5. 释放资源
        sqlSession.close();
        return det_scan_Code;
    }
}
