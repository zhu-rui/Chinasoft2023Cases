package ReportSystem.com.servlet;

import ReportSystem.com.pojo.PageBean;
import ReportSystem.com.pojo.count.*;
import ReportSystem.com.service.CountService;
import ReportSystem.com.service.impl.CountServiceImpl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.ParseException;

import java.util.HashMap;
import java.util.Map;

@WebServlet("/count/*")
public class CountServlet extends BaseServlet {
    private CountService CountService = new CountServiceImpl();
    //操作员
    public void selectUCByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<UCount> pageBean = CountService.selectUCByPageAndCondition(map);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    //每日营收

    public void selectCCByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<CCount> pageBean = CountService.selectCCByPageAndCondition(map);
        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    //TVM现金
    public void selectTCByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<TCCount> pageBean = CountService.selectTCByPageAndCondition(map);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    //TVM电子

    public void selectTEByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<TCCount> pageBean = CountService.selectTEByPageAndCondition(map);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    //BOM现金

    public void selectBCByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<BCCount> pageBean = CountService.selectBCByPageAndCondition(map);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    //BOM电子

    public void selectBEByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<BCCount> pageBean = CountService.selectBEByPageAndCondition(map);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    //总汇

    public void selectTOCByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //2. 调用service查询
        PageBean<TOCount> pageBean = CountService.selectTOCByPageAndCondition(map);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }
}
