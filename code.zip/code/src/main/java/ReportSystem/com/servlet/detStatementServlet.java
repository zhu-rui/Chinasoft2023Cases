package ReportSystem.com.servlet;


import ReportSystem.com.service.detStatementService;
import ReportSystem.com.service.impl.detStatementServiceImpl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import ReportSystem.com.pojo.detail.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/detail/*")
public class detStatementServlet extends BaseServlet{
    private detStatementService det_statementService = new detStatementServiceImpl();

    public void getDetSellCard(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //   /detail/getDetSellCard
       //1.从前端接收数据
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        List<det_sellC> det_sellc = det_statementService.getDetSellCard(map);
        //4. 转为JSON
        String jsonString = JSON.toJSONString(det_sellc);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    public void getDetReturnCard(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.从前端接收数据
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //3. 调用service查询
        List<det_returnC> det_returnc = det_statementService.getDetReturnCard(map);

        //4. 转为JSON
        String jsonString = JSON.toJSONString( det_returnc);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

    public void getDetRecharge(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.从前端接收数据
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //3. 调用service查询
        List<det_recharge> detrecharge = det_statementService.getDetRecharge(map);
        //4. 转为JSON
        String jsonString = JSON.toJSONString( detrecharge);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }


    public void getDetSwipCard(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.从前端接收数据
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //3. 调用service查询
        List<det_swipC> det_swipc  = det_statementService.getDetSwipCard(map);

        //4. 转为JSON
        String jsonString = JSON.toJSONString( det_swipc);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }



    public void getDetScanCode(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.从前端接收数据
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //3. 调用service查询
        List<det_scanCode> det_scan_Code = det_statementService.getDetScanCode(map);

        //4. 转为JSON
        String jsonString = JSON.toJSONString( det_scan_Code);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }

}
