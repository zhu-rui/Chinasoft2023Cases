package ReportSystem.com.servlet;

import ReportSystem.com.pojo.check.ExcTotal;
import ReportSystem.com.pojo.check.Except;
import ReportSystem.com.service.ExceptionService;
import ReportSystem.com.service.impl.ExceptionServiceImpl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/exception/*")
public class ExceptionServlet extends BaseServlet{
    private ExceptionService exceptionService = new ExceptionServiceImpl();
    public void selectECAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     //    /exception/selectECAll
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //3. 调用service查询
        List<Except> excepts = exceptionService.selectECAll(map);

        //4. 转为JSON
        String jsonString = JSON.toJSONString(excepts);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }


    public void selectETAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String urlQueryString1 = request.getQueryString();
        String urlQueryString=java.net.URLDecoder.decode(urlQueryString1,"utf-8");
        Map<String, String> map = new HashMap<>();
        String[] arrSplit;
        if (urlQueryString != null) {
            //每个键值为一组
            arrSplit = urlQueryString.split("[&]");
            for (String strSplit : arrSplit) {
                String[] arrSplitEqual = strSplit.split("[=]");
                //解析出键值
                if (arrSplitEqual.length > 1) {
                    map.put(arrSplitEqual[0], arrSplitEqual[1]);
                } else {
                    if (!"".equals(arrSplitEqual[0])) {
                        map.put(arrSplitEqual[0], null);
                    }
                }
            }
        }
        //3. 调用service查询
        List<ExcTotal> excTotals = exceptionService.selectETAll(map);

        //4. 转为JSON
        String jsonString = JSON.toJSONString(excTotals);
        //5. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);
    }
}
