package ReportSystem.com.pojo.detail;

import java.util.Date;

public class det_sellC {

    private String trans_sn;

    @Override
    public String toString() {
        return "det_sellC{" +
                ", trans_sn='" + trans_sn + '\'' +
                ", trans_type='" + trans_type + '\'' +
                ", card_no='" + card_no + '\'' +
                ", card_issuer='" + card_issuer + '\'' +
                ", ticket_type='" + ticket_type + '\'' +
                ", sell_time=" + sell_time +
                ", deposit=" + deposit +
                ", balance=" + balance +
                ", discount=" + discount +
                ", terminal_no='" + terminal_no + '\'' +
                ", user_id='" + user_id + '\'' +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }


    private String trans_type;

    private String card_no;

    private String card_issuer;

    private String ticket_type;

    private Date sell_time;

    private Integer deposit;

    private Integer balance;

    private Integer discount;

    private String terminal_no;

    private String user_id;

    private Date start_time;

    private Date end_time;

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getTrans_sn() {
        return trans_sn;
    }

    public void setTrans_sn(String trans_sn) {
        this.trans_sn = trans_sn;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCard_issuer() {
        return card_issuer;
    }

    public void setCard_issuer(String card_issuer) {
        this.card_issuer = card_issuer;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Date getSell_time() {
        return sell_time;
    }

    public void setSell_time(Date sell_time) {
        this.sell_time = sell_time;
    }

    public Integer getDeposit() {
        return deposit;
    }

    public void setDeposit(Integer deposit) {
        this.deposit = deposit;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public String getTerminal_no() {
        return terminal_no;
    }

    public void setTerminal_no(String terminal_no) {
        this.terminal_no = terminal_no;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
