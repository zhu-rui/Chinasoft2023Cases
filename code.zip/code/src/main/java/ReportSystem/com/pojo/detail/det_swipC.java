package ReportSystem.com.pojo.detail;

import java.io.Reader;
import java.util.Date;

public class det_swipC {
    private String trans_sn;
    private String trans_type;
    private String card_no;
    private String card_issuer;
    private String ticket_type;
    private Date swipCard_time;
    private Integer balance;
    private Integer swipCard_amount;
    private Integer discount;
    private Long terminal_trans_index;
    private String terminal_no;
    private Reader tac;
    private Date start_time;
    private Date end_time;

    @Override
    public String toString() {
        return "det_swipC{" +
                "trans_sn='" + trans_sn + '\'' +
                ", trans_type='" + trans_type + '\'' +
                ", card_no='" + card_no + '\'' +
                ", card_issuer='" + card_issuer + '\'' +
                ", ticket_type='" + ticket_type + '\'' +
                ", swipCard_time=" + swipCard_time +
                ", balance=" + balance +
                ", swipCard_amount=" + swipCard_amount +
                ", discount=" + discount +
                ", terminal_trans_index=" + terminal_trans_index +
                ", terminal_no='" + terminal_no + '\'' +
                ", tac=" + tac +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Long getTerminal_trans_index() {
        return terminal_trans_index;
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getTrans_sn() {
        return trans_sn;
    }

    public void setTrans_sn(String trans_sn) {
        this.trans_sn = trans_sn;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCard_issuer() {
        return card_issuer;
    }

    public void setCard_issuer(String card_issuer) {
        this.card_issuer = card_issuer;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Date getSwipCard_time() {
        return swipCard_time;
    }

    public void setSwipCard_time(Date swipCard_time) {
        this.swipCard_time = swipCard_time;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public Integer getSwipCard_amount() {
        return swipCard_amount;
    }

    public void setSwipCard_amount(Integer swipCard_amount) {
        this.swipCard_amount = swipCard_amount;
    }

    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public Long getTerminal_trans_index(String terminal_trans_index) {
        return this.terminal_trans_index;
    }

    public void setTerminal_trans_index(Long terminal_trans_index) {
        this.terminal_trans_index = terminal_trans_index;
    }

    public String getTerminal_no() {
        return terminal_no;
    }

    public void setTerminal_no(String terminal_no) {
        this.terminal_no = terminal_no;
    }

    public Reader getTac() {
        return tac;
    }

    public void setTac(Reader tac) {
        this.tac = tac;
    }
}
