package ReportSystem.com.pojo.count;

import java.util.Date;

public class CCount {
    //日期
    private Date trans_time;
    //票卡类型
    private String ticket_type;
    //储值卡BOM
    private Integer chuBC;
    //储值卡TVM
    private Integer chuTC;
    //普通卡
    private Integer puC;
    //学生卡
    private Integer xueC;
    //爱心卡
    private Integer aiC;
    //合计
    private Integer totC;
    //起始日期
    private Date start_time;
    //截止日期
    private Date end_time;


    @Override
    public String toString() {
        return "CCount{" +
                "trans_time=" + trans_time +
                ", ticket_type='" + ticket_type + '\'' +
                ", chuBC=" + chuBC +
                ", chuTC=" + chuTC +
                ", puC=" + puC +
                ", xueC=" + xueC +
                ", aiC=" + aiC +
                ", totC=" + totC +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Integer getChuBC() {
        return chuBC;
    }

    public void setChuBC(Integer chuBC) {
        this.chuBC = chuBC;
    }

    public Integer getChuTC() {
        return chuTC;
    }

    public void setChuTC(Integer chuTC) {
        this.chuTC = chuTC;
    }

    public Integer getPuC() {
        return puC;
    }

    public void setPuC(Integer puC) {
        this.puC = puC;
    }

    public Integer getXueC() {
        return xueC;
    }

    public void setXueC(Integer xueC) {
        this.xueC = xueC;
    }

    public Integer getAiC() {
        return aiC;
    }

    public void setAiC(Integer aiC) {
        this.aiC = aiC;
    }

    public Integer getTotC() {
        return totC;
    }

    public void setTotC(Integer totC) {
        this.totC = totC;
    }
}
