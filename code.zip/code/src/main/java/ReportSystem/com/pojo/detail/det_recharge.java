package ReportSystem.com.pojo.detail;

import java.util.Date;

public class det_recharge {
    private String trans_sn;
    private String trans_type;
    private String card_no;
    private String card_issuer;
    private String ticket_type;
    private Date recharge_time;
    private Integer balance;
    private Integer recharge_amount;
    private Integer discount;
    private String terminal_no;
    private String user_id;
    private Date start_time;
    private Date end_time;

    @Override
    public String toString() {
        return "det_recharge{" +
                "trans_sn='" + trans_sn + '\'' +
                ", trans_type='" + trans_type + '\'' +
                ", card_no='" + card_no + '\'' +
                ", card_issuer='" + card_issuer + '\'' +
                ", ticket_type='" + ticket_type + '\'' +
                ", recharge_time=" + recharge_time +
                ", balance=" + balance +
                ", recharge_amount=" + recharge_amount +
                ", discount=" + discount +
                ", terminal_no='" + terminal_no + '\'' +
                ", user_id='" + user_id + '\'' +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getTrans_sn() {
        return trans_sn;
    }

    public void setTrans_sn(String trans_sn) {
        this.trans_sn = trans_sn;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCard_issuer() {
        return card_issuer;
    }

    public void setCard_issuer(String card_issuer) {
        this.card_issuer = card_issuer;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Date getRecharge_time() {
        return recharge_time;
    }

    public void setRecharge_time(Date recharge_time) {
        this.recharge_time = recharge_time;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public Integer getRecharge_amount() {
        return recharge_amount;
    }

    public void setRecharge_amount(Integer recharge_amount) {
        this.recharge_amount = recharge_amount;
    }

    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public String getTerminal_no() {
        return terminal_no;
    }

    public void setTerminal_no(String terminal_no) {
        this.terminal_no = terminal_no;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
