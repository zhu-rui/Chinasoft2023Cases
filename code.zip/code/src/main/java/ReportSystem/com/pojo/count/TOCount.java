package ReportSystem.com.pojo.count;

import java.util.Date;

public class TOCount {
    //交易时间
    private Date trans_time;
    //人工现金押金
    private String Ucashdeposit;
    //人工电子支付押金
    private String Uedeposit;
    //人工现金充值
    private String Ucashcharge;
    //人工电子支付充值
    private String Uecharge;
    //自动售票现金押金
    private String Tcashdeposit;
    //自动售票电子押金
    private String Tedeposit;
    //自动售票现金充值
    private String Tcashcharge;
    //自动售票电子充值
    private String Techarge;
    //公众号待退款
    private String Cbackup;
    //公众号当日退款
    private String Cbackuped;
    //公众号售票
    private String Csell;
    //公众号消费
    private String Ccharge;
    //起始日期
    private Date start_time;
    //截止日期
    private Date end_time;

    @Override
    public String toString() {
        return "TOCount{" +
                "trans_time=" + trans_time +
                ", Ucashdeposit='" + Ucashdeposit + '\'' +
                ", Uedeposit='" + Uedeposit + '\'' +
                ", Ucashcharge='" + Ucashcharge + '\'' +
                ", Uecharge='" + Uecharge + '\'' +
                ", Tcashdeposit='" + Tcashdeposit + '\'' +
                ", Tedeposit='" + Tedeposit + '\'' +
                ", Tcashcharge='" + Tcashcharge + '\'' +
                ", Techarge='" + Techarge + '\'' +
                ", Cbackup='" + Cbackup + '\'' +
                ", Cbackuped='" + Cbackuped + '\'' +
                ", Csell='" + Csell + '\'' +
                ", Ccharge='" + Ccharge + '\'' +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getCsell() {
        return Csell;
    }

    public void setCsell(String csell) {
        Csell = csell;
    }

    public String getCcharge() {
        return Ccharge;
    }

    public void setCcharge(String ccharge) {
        Ccharge = ccharge;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public String getUcashdeposit() {
        return Ucashdeposit;
    }

    public void setUcashdeposit(String ucashdeposit) {
        Ucashdeposit = ucashdeposit;
    }

    public String getUedeposit() {
        return Uedeposit;
    }

    public void setUedeposit(String uedeposit) {
        Uedeposit = uedeposit;
    }

    public String getUcashcharge() {
        return Ucashcharge;
    }

    public void setUcashcharge(String ucashcharge) {
        Ucashcharge = ucashcharge;
    }

    public String getUecharge() {
        return Uecharge;
    }

    public void setUecharge(String uecharge) {
        Uecharge = uecharge;
    }

    public String getTcashdeposit() {
        return Tcashdeposit;
    }

    public void setTcashdeposit(String tcashdeposit) {
        Tcashdeposit = tcashdeposit;
    }

    public String getTedeposit() {
        return Tedeposit;
    }

    public void setTedeposit(String tedeposit) {
        Tedeposit = tedeposit;
    }

    public String getTcashcharge() {
        return Tcashcharge;
    }

    public void setTcashcharge(String tcashcharge) {
        Tcashcharge = tcashcharge;
    }

    public String getTecharge() {
        return Techarge;
    }

    public void setTecharge(String techarge) {
        Techarge = techarge;
    }

    public String getCbackup() {
        return Cbackup;
    }

    public void setCbackup(String cbackup) {
        Cbackup = cbackup;
    }

    public String getCbackuped() {
        return Cbackuped;
    }

    public void setCbackuped(String cbackuped) {
        Cbackuped = cbackuped;
    }
}
