package ReportSystem.com.pojo.detail;

import java.util.Date;

public class det_returnC {
    private String trans_sn;
    private String trans_type;
    private String card_no;
    private String card_issuer;
    private String ticket_type;
    private Date return_time;
    private Integer deposit;
    private Integer balance;
    private Integer return_money;
    private String terminal_no;
    private String user_id;
    private Date start_time;
    private Date end_time;

    @Override
    public String toString() {
        return "det_returnC{" +
                "trans_sn='" + trans_sn + '\'' +
                ", trans_type='" + trans_type + '\'' +
                ", card_no='" + card_no + '\'' +
                ", card_issuer='" + card_issuer + '\'' +
                ", ticket_type='" + ticket_type + '\'' +
                ", return_time=" + return_time +
                ", deposit=" + deposit +
                ", balance=" + balance +
                ", return_money=" + return_money +
                ", terminal_no='" + terminal_no + '\'' +
                ", user_id='" + user_id + '\'' +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getTrans_sn() {
        return trans_sn;
    }

    public void setTrans_sn(String trans_sn) {
        this.trans_sn = trans_sn;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCard_issuer() {
        return card_issuer;
    }

    public void setCard_issuer(String card_issuer) {
        this.card_issuer = card_issuer;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Date getReturn_time() {
        return return_time;
    }

    public void setReturn_time(Date return_time) {
        this.return_time = return_time;
    }

    public Integer getDeposit() {
        return deposit;
    }

    public void setDeposit(Integer deposit) {
        this.deposit = deposit;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public Integer getReturn_money() {
        return return_money;
    }

    public void setReturn_money(Integer return_money) {
        this.return_money = return_money;
    }

    public String getTerminal_no() {
        return terminal_no;
    }

    public void setTerminal_no(String terminal_no) {
        this.terminal_no = terminal_no;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
