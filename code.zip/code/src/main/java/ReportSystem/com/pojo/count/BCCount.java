package ReportSystem.com.pojo.count;

import java.util.Date;

public class BCCount {
    //充值点
    private String station_id;
    //设备编号
    private String terminal_no;
    //线路
    private String line_id;
    //票卡类型
    private String ticket_type;
    //张数 和之前那个一样，就是../的张数
    private Integer number;
    //金额 和之前那个一样，是../的押金或是金额
    private Float money;
    //交易时间
    private Date trans_time;
    //起始日期
    private Date start_time;
    //截止日期
    private Date end_time;

    @Override
    public String toString() {
        return "BCCount{" +
                "station_id='" + station_id + '\'' +
                ", terminal_no='" + terminal_no + '\'' +
                ", line_id='" + line_id + '\'' +
                ", ticket_type='" + ticket_type + '\'' +
                ", number=" + number +
                ", money=" + money +
                ", trans_time=" + trans_time +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public String getStation_id() {
        return station_id;
    }

    public void setStation_id(String station_id) {
        this.station_id = station_id;
    }

    public String getTerminal_no() {
        return terminal_no;
    }

    public void setTerminal_no(String terminal_no) {
        this.terminal_no = terminal_no;
    }

    public String getLine_id() {
        return line_id;
    }

    public void setLine_id(String line_id) {
        this.line_id = line_id;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Float getMoney() {
        return money;
    }

    public void setMoney(Float money) {
        this.money = money;
    }
}
