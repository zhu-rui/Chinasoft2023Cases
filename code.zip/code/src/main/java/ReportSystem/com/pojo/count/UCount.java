package ReportSystem.com.pojo.count;

import java.util.Date;


public class UCount {

    private Date trans_time;
    private String trans_type;
    private Integer number;
    private Integer money;
    private String user_id;
    private String terminal_no;
    private Date start_time;
    private Date end_time;

    @Override
    public String toString() {
        return "UCount{" +
                "trans_time=" + trans_time +
                ", trans_type='" + trans_type + '\'' +
                ", number=" + number +
                ", money=" + money +
                ", user_id='" + user_id + '\'' +
                ", terminal_no='" + terminal_no + '\'' +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTerminal_no() {
        return terminal_no;
    }

    public void setTerminal_no(String terminal_no) {
        this.terminal_no = terminal_no;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

}

