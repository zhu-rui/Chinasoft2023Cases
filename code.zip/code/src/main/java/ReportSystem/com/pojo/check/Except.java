package ReportSystem.com.pojo.check;

import java.sql.Date;

public class Except {
    private String  out_trade_no; //商户订单号
    private Date    trans_time; //交易时间
    private String  D_status; //邮储支付状态
    private Float   D_amount; //邮储总金额
    private String  D_type; //邮储支付方式
    private String  D_refund_no;//邮储退款订单号
    private Integer D_refund_status; //邮储退款状态
    private String  P_type;//系统支付方式
    private String  P_status;//系统支付状态
    private Float   P_amount;//系统支付总金额
    private Float   T_amount;//交易明细交易金额
    private Float   T_sn;//交易流水号
    private Date start_time;//起始时间
    private Date end_time;//截止时间

    @Override
    public String toString() {
        return "Exception{" +
                "out_trade_no='" + out_trade_no + '\'' +
                ", trans_time=" + trans_time +
                ", D_status='" + D_status + '\'' +
                ", D_amount=" + D_amount +
                ", D_type='" + D_type + '\'' +
                ", D_refund_no='" + D_refund_no + '\'' +
                ", D_refund_status=" + D_refund_status +
                ", P_type='" + P_type + '\'' +
                ", P_status='" + P_status + '\'' +
                ", P_amount=" + P_amount +
                ", T_amount=" + T_amount +
                ", T_sn=" + T_sn +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getOut_trade_no() {
        return out_trade_no;
    }

    public void setOut_trade_no(String out_trade_no) {
        this.out_trade_no = out_trade_no;
    }

    public Date getTrans_time() {

        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public String getD_status() {
        return D_status;
    }

    public void setD_status(String d_status) {
        D_status = d_status;
    }

    public Float getD_amount() {
        return D_amount;
    }

    public void setD_amount(Float d_amount) {
        D_amount = d_amount;
    }

    public String getD_type() {
        return D_type;
    }

    public void setD_type(String d_type) {
        D_type = d_type;
    }

    public String getD_refund_no() {
        return D_refund_no;
    }

    public void setD_refund_no(String d_refund_no) {
        D_refund_no = d_refund_no;
    }

    public Integer getD_refund_status() {
        return D_refund_status;
    }

    public void setD_refund_status(Integer d_refund_status) {
        D_refund_status = d_refund_status;
    }

    public String getP_type() {
        return P_type;
    }

    public void setP_type(String p_type) {
        P_type = p_type;
    }

    public String getP_status() {
        return P_status;
    }

    public void setP_status(String p_status) {
        P_status = p_status;
    }

    public Float getP_amount() {
        return P_amount;
    }

    public void setP_amount(Float p_amount) {
        P_amount = p_amount;
    }

    public Float getT_amount() {
        return T_amount;
    }

    public void setT_amount(Float t_amount) {
        T_amount = t_amount;
    }

    public Float getT_sn() {
        return T_sn;
    }

    public void setT_sn(Float t_sn) {
        T_sn = t_sn;
    }
}
