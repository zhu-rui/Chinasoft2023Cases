package ReportSystem.com.pojo.check;

import java.sql.Date;

public class ExcTotal {
    private Date trans_time;//日期
    private Float t_amount;//邮储支付收入金额
    private Float t_refund;//邮储退款金额
    private Float t_total;//邮储总金额
    private Integer t_number;//邮储总笔数
    private Float s_amount;//系统支付收入金额
    private Float s_refund;//系统支付退款金额
    private Float s_total;//系统支付总金额
    private Integer s_number;//系统支付总笔数
    private Date start_time;//起始时间
    private Date end_time;//截止时间

    @Override
    public String toString() {
        return "ExcTotal{" +
                "trans_time=" + trans_time +
                ", t_amount=" + t_amount +
                ", t_refund=" + t_refund +
                ", t_total=" + t_total +
                ", t_number=" + t_number +
                ", s_amount=" + s_amount +
                ", s_refund=" + s_refund +
                ", s_total=" + s_total +
                ", s_number=" + s_number +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public Float getT_amount() {
        return t_amount;
    }

    public void setT_amount(Float t_amount) {
        this.t_amount = t_amount;
    }

    public Float getT_refund() {
        return t_refund;
    }

    public void setT_refund(Float t_refund) {
        this.t_refund = t_refund;
    }

    public Float getT_total() {
        return t_total;
    }

    public void setT_total(Float t_total) {
        this.t_total = t_total;
    }

    public Integer getT_number() {
        return t_number;
    }

    public void setT_number(Integer t_number) {
        this.t_number = t_number;
    }

    public Float getS_amount() {
        return s_amount;
    }

    public void setS_amount(Float s_amount) {
        this.s_amount = s_amount;
    }

    public Float getS_refund() {
        return s_refund;
    }

    public void setS_refund(Float s_refund) {
        this.s_refund = s_refund;
    }

    public Float getS_total() {
        return s_total;
    }

    public void setS_total(Float s_total) {
        this.s_total = s_total;
    }

    public Integer getS_number() {
        return s_number;
    }

    public void setS_number(Integer s_number) {
        this.s_number = s_number;
    }
}
