package ReportSystem.com.pojo.detail;

import java.util.Date;

public class det_scanCode {
    private String trans_sn;
    private String voucher_no;

    private String ticket_type;
    private Date trans_time;
    private String trans_type;
    private Integer scanCode_amount;
    private Date start_time;
    private Date end_time;

    @Override
    public String toString() {
        return "det_scanCode{" +
                "trans_sn='" + trans_sn + '\'' +
                ", voucher_no='" + voucher_no + '\'' +
                ", ticket_type='" + ticket_type + '\'' +
                ", trans_time=" + trans_time +
                ", trans_type='" + trans_type + '\'' +
                ", scanCode_amount=" + scanCode_amount +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getTrans_sn() {
        return trans_sn;
    }

    public void setTrans_sn(String trans_sn) {
        this.trans_sn = trans_sn;
    }

    public String getVoucher_no() {
        return voucher_no;
    }

    public void setVoucher_no(String voucher_no) {
        this.voucher_no = voucher_no;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getTicket_type() {
        return ticket_type;
    }

    public void setTicket_type(String ticket_type) {
        this.ticket_type = ticket_type;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    public Integer getScanCode_amount() {
        return scanCode_amount;
    }

    public void setScanCode_amount(Integer ScanCode_amount) {
        this.scanCode_amount = ScanCode_amount;
    }
}
